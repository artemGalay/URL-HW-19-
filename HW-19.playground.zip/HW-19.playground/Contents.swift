import UIKit

func getData(urlRequest: String) {
    let urlRequest = URL(string: urlRequest)
    let configuration = URLSessionConfiguration.default
    configuration.allowsCellularAccess = true // когда отключён Wi-Fi
    guard let url = urlRequest else { return }
    URLSession.shared.dataTask(with: url) { (data, response, error) in
        if let error = error {
            print("error: \(error.localizedDescription)")
        } else {
            if let response = response as? HTTPURLResponse, response.statusCode == 200 {
                print("statusCode: \(response.statusCode)")
            }
            if let data = data,
               let dataAsString = String(data: data, encoding: .utf8) {
                print("data: \(dataAsString)")
            }
        }
    } .resume()
}

let url = "https://dog.ceo/api/breeds/image/random"
getData(urlRequest: url)
